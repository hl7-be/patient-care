# Example Patient - JSON Representation - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Patient**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/master](https://github.com/hl7-be/patient-care/tree/master) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Narrative Content](Patient-patient1.md) 
*  [XML](Patient-patient1.xml.md) 
*  [JSON](#) 
*  [TTL](Patient-patient1.ttl.md) 

## : Example Patient - JSON Representation

[Raw json](Patient-patient1.json) | [Download](Patient-patient1.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](Patient-patient1.xml.md) | [top](#top) |  [next>](Patient-patient1.ttl.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

