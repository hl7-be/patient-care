# BECarePlan - TTL Representation - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BECarePlan**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/master](https://github.com/hl7-be/patient-care/tree/master) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](StructureDefinition-be-care-plan.md) 
*  [Detailed Descriptions](StructureDefinition-be-care-plan-definitions.md) 
*  [Mappings](StructureDefinition-be-care-plan-mappings.md) 
*  [XML](StructureDefinition-be-care-plan.profile.xml.md) 
*  [JSON](StructureDefinition-be-care-plan.profile.json.md) 
*  [TTL](#) 

## Resource Profile: BeCarePlan - TTL Profile

| |
| :--- |
| Active as of 2021-01-18 |

TTL representation of the be-care-plan resource profile.

[Raw ttl](StructureDefinition-be-care-plan.ttl) | [Download](StructureDefinition-be-care-plan.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-be-care-plan.profile.json.md) | [top](#top) |  [next>](StructureDefinition-be-careteam.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

