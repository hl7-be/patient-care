# BECarePlan - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BECarePlan**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/master](https://github.com/hl7-be/patient-care/tree/master) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-be-care-plan-definitions.md) 
*  [Mappings](StructureDefinition-be-care-plan-mappings.md) 
*  [XML](StructureDefinition-be-care-plan.profile.xml.md) 
*  [JSON](StructureDefinition-be-care-plan.profile.json.md) 
*  [TTL](StructureDefinition-be-care-plan.profile.ttl.md) 

## Resource Profile: BECarePlan 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-care-plan | *Version*:1.1.0 |
| Active as of 2021-01-18 | *Computable Name*:BeCarePlan |

 
This is the profile for Care Plan. A Care Plan contains the activities planned and/or performed by a care team to deliver care for a particular patient, usually targeting a specific goal or condition - or a set thereof. 

**Usages:**

* Refer to this Profile: [BECarePlan](StructureDefinition-be-care-plan.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.patient-care|current/StructureDefinition/be-care-plan)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CarePlan](http://hl7.org/fhir/R4/careplan.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CarePlan](http://hl7.org/fhir/R4/careplan.html) 

**Summary**

Must-Support: 17 elements

**Structures**

This structure refers to these other structures:

* [BECarePlan(https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-care-plan)](StructureDefinition-be-care-plan.md)
* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BePractitionerRole(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitionerrole)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitionerrole.html)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [BeCareTeam(https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-careteam)](StructureDefinition-be-careteam.md)
* [BeGoal(https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-goal)](StructureDefinition-be-goal.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of CarePlan.identifier

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [CarePlan](http://hl7.org/fhir/R4/careplan.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [CarePlan](http://hl7.org/fhir/R4/careplan.html) 

**Summary**

Must-Support: 17 elements

**Structures**

This structure refers to these other structures:

* [BECarePlan(https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-care-plan)](StructureDefinition-be-care-plan.md)
* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BePractitionerRole(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitionerrole)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitionerrole.html)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [BeCareTeam(https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-careteam)](StructureDefinition-be-careteam.md)
* [BeGoal(https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-goal)](StructureDefinition-be-goal.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of CarePlan.identifier

 

Other representations of profile: [CSV](StructureDefinition-be-care-plan.csv), [Excel](StructureDefinition-be-care-plan.xlsx), [Schematron](StructureDefinition-be-care-plan.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeModelTask.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-be-care-plan-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

