# BeTask - Testing - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeTask**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/master](https://github.com/hl7-be/patient-care/tree/master) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](StructureDefinition-be-task.md) 
*  [Detailed Descriptions](StructureDefinition-be-task-definitions.md) 
*  [Mappings](StructureDefinition-be-task-mappings.md) 
*  [XML](StructureDefinition-be-task.profile.xml.md) 
*  [JSON](StructureDefinition-be-task.profile.json.md) 
*  [TTL](StructureDefinition-be-task.profile.ttl.md) 

## Resource Profile: BeTask - Testing

| |
| :--- |
| Active as of 2021-01-18 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-be-task-mappings.md) | [top](#top) |  [next>](StructureDefinition-be-task.profile.xml.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

