# BeCareTeam - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeCareTeam**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/master](https://github.com/hl7-be/patient-care/tree/master) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-be-careteam-definitions.md) 
*  [Mappings](StructureDefinition-be-careteam-mappings.md) 
*  [XML](StructureDefinition-be-careteam.profile.xml.md) 
*  [JSON](StructureDefinition-be-careteam.profile.json.md) 
*  [TTL](StructureDefinition-be-careteam.profile.ttl.md) 

## Resource Profile: BeCareTeam 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-careteam | *Version*:1.1.0 |
| Active as of 2021-01-18 | *Computable Name*:BeCareTeam |

 
This is the Belgian profile for care team. A care team defines the people and roles organized around a patient’s care activities planned. It may also imply additional aspects such as access to information etc. 

**Usages:**

* Refer to this Profile: [BECarePlan](StructureDefinition-be-care-plan.md), [BeCareTeam](StructureDefinition-be-careteam.md) and [BeTask](StructureDefinition-be-task.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.patient-care|current/StructureDefinition/be-careteam)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CareTeam](http://hl7.org/fhir/R4/careteam.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [CareTeam](http://hl7.org/fhir/R4/careteam.html) 

**Summary**

Must-Support: 8 elements

**Structures**

This structure refers to these other structures:

* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [BePractitionerRole(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitionerrole)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitionerrole.html)
* [BeCareTeam(https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-careteam)](StructureDefinition-be-careteam.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [CareTeam](http://hl7.org/fhir/R4/careteam.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [CareTeam](http://hl7.org/fhir/R4/careteam.html) 

**Summary**

Must-Support: 8 elements

**Structures**

This structure refers to these other structures:

* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [BePractitionerRole(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitionerrole)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitionerrole.html)
* [BeCareTeam(https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-careteam)](StructureDefinition-be-careteam.md)

 

Other representations of profile: [CSV](StructureDefinition-be-careteam.csv), [Excel](StructureDefinition-be-careteam.xlsx), [Schematron](StructureDefinition-be-careteam.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-be-care-plan.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-be-careteam-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

