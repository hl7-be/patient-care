# BeGoal - Definitions - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeGoal**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/master](https://github.com/hl7-be/patient-care/tree/master) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](StructureDefinition-be-goal.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-be-goal-mappings.md) 
*  [XML](StructureDefinition-be-goal.profile.xml.md) 
*  [JSON](StructureDefinition-be-goal.profile.json.md) 
*  [TTL](StructureDefinition-be-goal.profile.ttl.md) 

## Resource Profile: BeGoal - Detailed Descriptions

| |
| :--- |
| Active as of 2021-01-18 |

Definitions for the be-goal resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-be-goal.md) | [top](#top) |  [next>](StructureDefinition-be-goal-mappings.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

