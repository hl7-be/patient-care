# Table of Contents - HL7 Belgium Patient Care v1.1.0

* **Table of Contents**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/master](https://github.com/hl7-be/patient-care/tree/master) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 IG Home Page](index.md) |
| [2 Guidance](guidance.md) |
| [3 Changes](changes.md) |
| [4 Downloads](downloads.md) |
| [5 Artifacts Summary](artifacts.md) |
| [5.1 BeModelCarePlan](StructureDefinition-BeModelCarePlan.md) |
| [5.2 BeModelCareTeam](StructureDefinition-BeModelCareTeam.md) |
| [5.3 BeModelGoal](StructureDefinition-BeModelGoal.md) |
| [5.4 BeModelTask](StructureDefinition-BeModelTask.md) |
| [5.5 BECarePlan](StructureDefinition-be-care-plan.md) |
| [5.6 BeCareTeam](StructureDefinition-be-careteam.md) |
| [5.7 BeGoal](StructureDefinition-be-goal.md) |
| [5.8 BeTask](StructureDefinition-be-task.md) |
| [5.9 Example Patient](Patient-patient1.md) |

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  [next>](index.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

