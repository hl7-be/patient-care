# Guidance - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* **Guidance**

## Guidance

