# Changes - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* **Changes**

## Changes

 This provides a list of changes to the specification since its initial release 

**2025-09-26 v1.1.0 - eHealth Platform Federal Patient-care Profiles** based on FHIR 4.0.1

* [Release notes on GitHub](https://github.com/hl7-be/patient-care/releases/tag/v1.1.0)

 **2025-05-08 v1.0.0 - Published** based on FHIR R4 

* First published release

