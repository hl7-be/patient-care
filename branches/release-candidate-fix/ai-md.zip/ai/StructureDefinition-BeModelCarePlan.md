# BeModelCarePlan - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeModelCarePlan**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/38/merge](https://github.com/hl7-be/patient-care/tree/38/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BeModelCarePlan-definitions.md) 
*  [Mappings](StructureDefinition-BeModelCarePlan-mappings.md) 
*  [XML](StructureDefinition-BeModelCarePlan.profile.xml.md) 
*  [JSON](StructureDefinition-BeModelCarePlan.profile.json.md) 
*  [TTL](StructureDefinition-BeModelCarePlan.profile.ttl.md) 

## Logical Model: BeModelCarePlan 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/BeModelCarePlan | *Version*:1.1.0 |
| Active as of 2025-10-06 | *Computable Name*:BeModelCarePlan |

 
Logical model for Care Plan. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.patient-care|current/StructureDefinition/BeModelCarePlan)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Constraints

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(1 nested mandatory element)

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Key Elements View** 

#### Constraints

 **Snapshot View** 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(1 nested mandatory element)

 

Other representations of profile: [CSV](StructureDefinition-BeModelCarePlan.csv), [Excel](StructureDefinition-BeModelCarePlan.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](artifacts.md) | [top](#top) |  [next>](StructureDefinition-BeModelCarePlan-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

