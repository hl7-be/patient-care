# BeModelGoal - Definitions - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeModelGoal**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/38/merge](https://github.com/hl7-be/patient-care/tree/38/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](StructureDefinition-BeModelGoal.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-BeModelGoal-mappings.md) 
*  [XML](StructureDefinition-BeModelGoal.profile.xml.md) 
*  [JSON](StructureDefinition-BeModelGoal.profile.json.md) 
*  [TTL](StructureDefinition-BeModelGoal.profile.ttl.md) 

## Logical Model: BeModelGoal - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-03 |

Definitions for the BeModelGoal logical model.

*  [Differential Elements Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeModelGoal.md) | [top](#top) |  [next>](StructureDefinition-BeModelGoal-mappings.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

