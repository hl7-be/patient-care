#  - HL7 Belgium Patient Care v1.1.0

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/38/merge](https://github.com/hl7-be/patient-care/tree/38/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](StructureDefinition-BeModelCareTeam.md) 
*  [Detailed Descriptions](StructureDefinition-BeModelCareTeam-definitions.md) 
*  [Mappings](StructureDefinition-BeModelCareTeam-mappings.md) 
*  [XML](StructureDefinition-BeModelCareTeam.profile.xml.md) 
*  [JSON](StructureDefinition-BeModelCareTeam.profile.json.md) 
*  [TTL](StructureDefinition-BeModelCareTeam.profile.ttl.md) 

## Logical Model: BeModelCareTeam - Examples

| |
| :--- |
| Active as of 2025-10-03 |

**No examples are currently available for the Profile.**

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

