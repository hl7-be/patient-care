# BeModelGoal - Mappings - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeModelGoal**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/38/merge](https://github.com/hl7-be/patient-care/tree/38/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](StructureDefinition-BeModelGoal.md) 
*  [Detailed Descriptions](StructureDefinition-BeModelGoal-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-BeModelGoal.profile.xml.md) 
*  [JSON](StructureDefinition-BeModelGoal.profile.json.md) 
*  [TTL](StructureDefinition-BeModelGoal.profile.ttl.md) 

## Logical Model: BeModelGoal - Mappings

| |
| :--- |
| Active as of 2025-10-03 |

Mappings for the BeModelGoal logical model.

No Mappings

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeModelGoal-definitions.md) | [top](#top) |  [next>](StructureDefinition-BeModelGoal-testing.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

