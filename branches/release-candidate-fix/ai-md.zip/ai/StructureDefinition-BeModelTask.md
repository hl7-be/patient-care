# BeModelTask - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeModelTask**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/38/merge](https://github.com/hl7-be/patient-care/tree/38/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BeModelTask-definitions.md) 
*  [Mappings](StructureDefinition-BeModelTask-mappings.md) 
*  [XML](StructureDefinition-BeModelTask.profile.xml.md) 
*  [JSON](StructureDefinition-BeModelTask.profile.json.md) 
*  [TTL](StructureDefinition-BeModelTask.profile.ttl.md) 

## Logical Model: BeModelTask 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/BeModelTask | *Version*:1.1.0 |
| Active as of 2025-10-03 | *Computable Name*:BeModelTask |

 
Logical model for Task. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.patient-care|current/StructureDefinition/BeModelTask)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(2 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [ValueSet Reference(http://hl7.org/fhir/StructureDefinition/valueset-reference)](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-valueset-reference.html)

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Key Elements View** 

 **Snapshot View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(2 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [ValueSet Reference(http://hl7.org/fhir/StructureDefinition/valueset-reference)](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-valueset-reference.html)

 

Other representations of profile: [CSV](StructureDefinition-BeModelTask.csv), [Excel](StructureDefinition-BeModelTask.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeModelGoal.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BeModelTask-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

