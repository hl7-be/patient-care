#  - HL7 Belgium Patient Care v1.1.0

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/38/merge](https://github.com/hl7-be/patient-care/tree/38/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](StructureDefinition-be-task.md) 
*  [Detailed Descriptions](StructureDefinition-be-task-definitions.md) 
*  [Mappings](StructureDefinition-be-task-mappings.md) 
*  [XML](StructureDefinition-be-task.profile.xml.md) 
*  [JSON](StructureDefinition-be-task.profile.json.md) 
*  [TTL](StructureDefinition-be-task.profile.ttl.md) 

## Resource Profile: BeTask - Examples

| |
| :--- |
| Active as of 2021-01-18 |

**No examples are currently available for the Profile.**

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

