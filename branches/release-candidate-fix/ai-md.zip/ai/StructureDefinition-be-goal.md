# BeGoal - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeGoal**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/38/merge](https://github.com/hl7-be/patient-care/tree/38/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-be-goal-definitions.md) 
*  [Mappings](StructureDefinition-be-goal-mappings.md) 
*  [XML](StructureDefinition-be-goal.profile.xml.md) 
*  [JSON](StructureDefinition-be-goal.profile.json.md) 
*  [TTL](StructureDefinition-be-goal.profile.ttl.md) 

## Resource Profile: BeGoal 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/patient-care/StructureDefinition/be-goal | *Version*:1.1.0 |
| Active as of 2021-01-18 | *Computable Name*:BeGoal |

 
This is the profile for Goal. 

**Usages:**

* Refer to this Profile: [BECarePlan](StructureDefinition-be-care-plan.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.patient-care|current/StructureDefinition/be-goal)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Goal](http://hl7.org/fhir/R4/goal.html) 

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Goal](http://hl7.org/fhir/R4/goal.html) 

**Summary**

Must-Support: 6 elements

**Structures**

This structure refers to these other structures:

* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Goal.identifier

 **Differential View** 

This structure is derived from [Goal](http://hl7.org/fhir/R4/goal.html) 

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Goal](http://hl7.org/fhir/R4/goal.html) 

**Summary**

Must-Support: 6 elements

**Structures**

This structure refers to these other structures:

* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Goal.identifier

 

Other representations of profile: [CSV](StructureDefinition-be-goal.csv), [Excel](StructureDefinition-be-goal.xlsx), [Schematron](StructureDefinition-be-goal.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-be-careteam.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-be-goal-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

