# Artifacts Summary - HL7 Belgium Patient Care v1.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

HL7 Belgium Patient Care, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/patient-care/tree/38/merge](https://github.com/hl7-be/patient-care/tree/38/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/patient-care/history.html)

## Artifacts Summary

Contents:

*  [Structures: Logical Models](#1) 
*  [Structures: Resource Profiles](#2) 

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Logical Models 

These define data models that represent the domain covered by this implementation guide in more business-friendly terms than the underlying FHIR resources.

| | |
| :--- | :--- |
| [BeModelCarePlan](StructureDefinition-BeModelCarePlan.md) | Logical model for Care Plan. |
| [BeModelCareTeam](StructureDefinition-BeModelCareTeam.md) | Logical model for Care Teams. |
| [BeModelGoal](StructureDefinition-BeModelGoal.md) | Logical model for Goal. |
| [BeModelTask](StructureDefinition-BeModelTask.md) | Logical model for Task. |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [BECarePlan](StructureDefinition-be-care-plan.md) | This is the profile for Care Plan. A Care Plan contains the activities planned and/or performed by a care team to deliver care for a particular patient, usually targeting a specific goal or condition - or a set thereof. |
| [BeCareTeam](StructureDefinition-be-careteam.md) | This is the Belgian profile for care team. A care team defines the people and roles organized around a patient’s care activities planned. It may also imply additional aspects such as access to information etc. |
| [BeGoal](StructureDefinition-be-goal.md) | This is the profile for Goal. |
| [BeTask](StructureDefinition-be-task.md) | This is the profile for Task. |

| | | |
| :--- | :--- | :--- |
|  [<prev](downloads.md) | [top](#top) |  [next>](StructureDefinition-BeModelCarePlan.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.patient-care#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

